﻿/*Created in México:
 * Edited by: Sebastian M. P. 
 * For using this arduino program you will need a NODEMCU8266 
 * This dll will help you to control the car via Wifi 
 *********Read the instructions to know how to use it in Windows Forms 
 */


using System.Net.Http;
using System.Net;
using System.Net.Sockets;

namespace car_wifi
{
    public class Class1
    {
        public async void  all (string a, char b)
        {
            
            try
            {
               
                HttpClient cliente = new HttpClient();
                HttpResponseMessage request = await cliente.GetAsync("http://"+a+"/"+b+"x");
                string reponsebo = await request.Content.ReadAsStringAsync();    
                
            
            }
            catch
            {

            }
             
        }
       
    }
}
