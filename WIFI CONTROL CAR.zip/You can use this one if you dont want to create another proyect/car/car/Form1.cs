﻿/*
 * 
 * 
 * 
 * 
 * 
 * 
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using car_wifi;
using System.Net.Http;
using System.Net;
using System.Net.Sockets;
namespace car
{
    public partial class Form1 : Form
    {
        Class1 obj = new Class1();
        public Form1()
        {
            InitializeComponent();
        }
        private async void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                obj.all(textBox1.Text.ToString(), Convert.ToChar(textBox2.Text));
                textBox2.Clear ();

            }
            catch
            {

            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }
    }
}
